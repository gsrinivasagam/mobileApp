public class ReversePairs {
    public static void main(String[] args) {
        int[] nums = {1,3,2,3,1};

    }


}
