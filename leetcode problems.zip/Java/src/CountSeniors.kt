class CountSeniors {
}