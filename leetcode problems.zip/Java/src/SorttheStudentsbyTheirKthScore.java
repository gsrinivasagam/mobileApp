public class SorttheStudentsbyTheirKthScore {
}
