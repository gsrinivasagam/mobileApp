public class MaximumValueofaStringinanArray {
    public static void main(String[] args) {
        String s = "0001";
        System.out.println(s.replaceFirst("^0*",""));
    }

//    public static int maximumValue(String[] strs) {
//
//    }
}
