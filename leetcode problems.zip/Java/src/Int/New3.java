//package Int;
//
////Map
//// A: 1
////B:3
////c:2
////D:5
//
//import java.util.HashMap;
//import java.util.Map;
//
//public class New3 {
//    public static void main(String[] args) {
//        Map<Character,Integer> map = new HashMap<>();
//        map.put('A',1);
//
//        int[] arr = new int[10];
//        for()
//        .sorted(compare.comparingInt())
//
//    }
//}
