//package Int;
//
//public class Int4 {
//    public static void main(String[] args) {
//        int result= test();
//        syso(result);
//    }
//
//    int static test()
//    {
//        try { return 10/0; }
//        catch(Exception e) {
//            return 2;
//        }
//        finally { return 3; }
//    }
////    psvm() {  }
//}
//
//
