//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//public class SplittheArray {
//    public static void main(String[] args) {
//
//    }
//
//    public static boolean isPossibleToSplit(int[] nums) {
//        Set<Integer> set = new HashSet();
//        Set<Integer> set2 = new HashSet();
//        List<Integer> list = new ArrayList<>();
//
//        for(int n : nums){
//            list.add(n);
//        }
//
//        for (int n : nums){
//            if(!set.contains(n)){
//                set.add(n);
//                list.remove(n);
//            } else{
//
//            }
//        }
//
//
//    }
//}
