//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//public class int6 {
//    public static void main(String[] args) {
////        int[] arr = {1,2,3,4,5,6,7,8};
//        List<Integer> list = new ArrayList<>();
//        list.add(1);
//        list.add(2);
//        list.add(3);
//        list.add(4);
//        list.add(5);
//        list.add(6);
//        list.add(7);
//
//
////        List<int[]> list = Arrays.asList(arr);
//
//      list.stream().some
//
////        boolean flag = true;
////        for(int i : list){
////
////            if(i%2==0) {
////                flag = false;
////                break;
////            }
////        }
////
////        if(flag)
////            System.out.println("It is fully odd");
////        else
////        System.out.println("it is not only odd");
//    }
//}
//
//arr -n
//
//
//
//
//
////    int[] arr = {1,2,3,4,5,6,7,8};
////    List<Integers> list = Arrays.asList(arr);
////
////  list.stream().filter(i -> i%2!=0).forEach(System.out::Println);\
////
////          boolean flag = true;
////          for(int i : list){
////
////          if(i%2==0)
////          flag = false;
////          break;
////          }
////
////          if(flag)
////          Sout("It is fully odd")
////          else
////          sout("it is not only odd");
//
////
////          10
////          11
////          100
////          101
////          110
////          111
//
