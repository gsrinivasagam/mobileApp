public class RotateString {
    public static void main(String[] args) {

    }

    
}
