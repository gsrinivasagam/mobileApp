public class HouseRobber2 {
}
