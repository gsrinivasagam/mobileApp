package Java8.Streams;

public class PrintTheFirst10EvenNumbersUsingjavaStreams {
    public static void main(String[] args) {
        generateEvenNumbers(10);
    }

    public static void generateEvenNumbers(int n){
//            IntStream.iterate(2,i->i+2).limit(10).forEach();
    }
}
